/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y44
 */

#ifndef xconfig_clock__
#define xconfig_clock__



#endif /* xconfig_clock__ */ 
