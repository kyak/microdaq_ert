/* main.c -- rtiostream main
 *
 * Copyright (C) 2013 Embedded Solutions
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

#include "rtiostreamtest.h"

Void taskFxn(UArg a0, UArg a1)
{
    System_printf("Starting rtiostream test suite.\n");
	rtiostreamtest(0, NULL);
	BIOS_exit(0);
}

Void main()
{ 
    Task_Handle task;

    task = Task_create(taskFxn, NULL, NULL);
    if (task == NULL) {
        System_printf("Task_create() failed!\n");
        BIOS_exit(0);
    }

    BIOS_start();     /* enable interrupts and start SYS/BIOS */
}
